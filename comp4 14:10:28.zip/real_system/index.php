<?php 

include 'includes/header.php';

?>
<h2> Hello, <?php echo $user_data['first_name']; ?>!</h2>

Hello