<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(-1);
?>

<html>
<head>
<title><?php echo "Business "; ?>Hello</title>
<link rel="stylesheet" href="
<?php echo "http://localhost/booker/real_system/assets/style.css";?>"/>

</head>
<body>
	<div id="heading">
		<div id="branding">
		tits mcgee
		</div>
	</div>
<div id="container">