
<?php
include('includes/header.php');
?>
<h1>Okay, It's time to confirm.</h1>
<h1>Okay, It's been confirmed.</h1>