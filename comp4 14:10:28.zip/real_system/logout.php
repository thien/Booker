<?php 

session_start();

session_destroy();
$expiry = time()-60*60;

header('Location: login.php');	

?>