Copyright (C) 2013 by Mark Hudson | www.planetphp.co.uk

License:
Freeware License Agreement

Installation

1. Create a MySQL table called `bookings`.  I have included the schema in the SQL file 'calendar_table_schema.sql'
2. Open the php folder and alter the database settings
3  Upload the folder to the server 